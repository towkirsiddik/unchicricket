package com.example.unchi_cricket

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
